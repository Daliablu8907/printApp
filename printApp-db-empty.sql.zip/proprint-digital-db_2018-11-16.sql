-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 16, 2018 at 02:32 PM
-- Server version: 5.6.35
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proprint-digital`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_activities`
--

CREATE TABLE `app_activities` (
  `activity_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `activity` text NOT NULL,
  `module` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `deleted` tinyint(12) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `app_approved_designs`
--

CREATE TABLE `app_approved_designs` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `job_design_id` int(11) DEFAULT NULL,
  `approved_by` varchar(225) NOT NULL,
  `date_approved` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_binding_jobs`
--

CREATE TABLE `app_binding_jobs` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `binding_type_id` int(11) DEFAULT NULL,
  `qty` int(225) NOT NULL,
  `bound_by` varchar(225) NOT NULL,
  `is_dispatched` enum('0','1') NOT NULL DEFAULT '0',
  `date_bound` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_binding_jobs_dispatch_jobs`
--

CREATE TABLE `app_binding_jobs_dispatch_jobs` (
  `id` int(11) NOT NULL,
  `binding_job_id` int(11) DEFAULT NULL,
  `dispatch_job_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_binding_types`
--

CREATE TABLE `app_binding_types` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_binding_types`
--

INSERT INTO `app_binding_types` (`id`, `name`) VALUES
(1, 'No Binding'),
(2, 'Saddle Stitch'),
(3, 'Spiral Bind'),
(4, 'Perfect Bind');

-- --------------------------------------------------------

--
-- Table structure for table `app_company`
--

CREATE TABLE `app_company` (
  `pk_i_id` int(11) NOT NULL,
  `s_name` varchar(225) NOT NULL,
  `s_vat_no` varchar(225) NOT NULL,
  `s_tpin` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_company`
--

INSERT INTO `app_company` (`pk_i_id`, `s_name`, `s_vat_no`, `s_tpin`) VALUES
(1, 'ABC Limited', '32630201-81', '10000258878');

-- --------------------------------------------------------

--
-- Table structure for table `app_complete_job_cards`
--

CREATE TABLE `app_complete_job_cards` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `issue_complete` enum('0','1') NOT NULL DEFAULT '1',
  `issue_date` date DEFAULT '0000-00-00',
  `design_complete` enum('0','1') NOT NULL DEFAULT '0',
  `date_design_complete` date DEFAULT '0000-00-00',
  `print_complete` enum('0','1') NOT NULL DEFAULT '0',
  `date_print_complete` date DEFAULT '0000-00-00',
  `binding_complete` enum('0','1') NOT NULL DEFAULT '0',
  `date_binding_complete` date DEFAULT '0000-00-00',
  `dispatch_complete` enum('0','1') NOT NULL DEFAULT '0',
  `date_dispatch_complete` date DEFAULT '0000-00-00',
  `job_complete` enum('0','1') NOT NULL DEFAULT '0',
  `date_job_complete` date DEFAULT '0000-00-00',
  `is_closed` enum('0','1') NOT NULL DEFAULT '0',
  `date_closed` date DEFAULT '0000-00-00',
  `date` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_customers`
--

CREATE TABLE `app_customers` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `contact` varchar(225) DEFAULT NULL,
  `address` text,
  `town` varchar(225) DEFAULT NULL,
  `country` varchar(225) DEFAULT NULL,
  `is_company` enum('0','1') NOT NULL DEFAULT '0',
  `contact_name` varchar(225) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_customers_job_cards`
--

CREATE TABLE `app_customers_job_cards` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_designs`
--

CREATE TABLE `app_designs` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `designer_name` varchar(225) NOT NULL,
  `period` int(11) NOT NULL,
  `period_type` enum('days','weeks','months','year') NOT NULL DEFAULT 'days',
  `designed_by_customer` enum('0','1') NOT NULL DEFAULT '0',
  `flag_complete` enum('0','1') NOT NULL DEFAULT '0',
  `flag_approved` enum('0','1') DEFAULT '0',
  `signed_by` varchar(225) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `approved_by` varchar(225) DEFAULT NULL,
  `approved_date` date DEFAULT '0000-00-00',
  `date_accepted` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_designs_drafts`
--

CREATE TABLE `app_designs_drafts` (
  `id` int(11) NOT NULL,
  `design_id` int(11) DEFAULT NULL,
  `draft_id` int(11) DEFAULT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_dispatche`
--

CREATE TABLE `app_dispatche` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `delivery_note` int(225) NOT NULL,
  `invoice_no` int(225) NOT NULL,
  `dispatch_date` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_dispatches`
--

CREATE TABLE `app_dispatches` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_dispatches`
--

INSERT INTO `app_dispatches` (`id`, `job_card_id`, `date_modified`) VALUES
(1, 3, '2018-04-04 13:55:10'),
(2, 1, '2018-04-04 13:55:10'),
(3, 2, '2018-04-04 13:55:15'),
(4, 5, '2018-04-04 13:55:15'),
(5, 7, '2018-04-04 13:55:15'),
(6, 8, '2018-04-04 13:55:15'),
(7, 9, '2018-04-04 13:55:15'),
(8, 13, '2018-04-04 13:55:15'),
(9, 225, '2018-04-04 13:55:15'),
(10, 245, '2018-04-04 13:55:15'),
(11, 293, '2018-04-04 13:55:15'),
(12, 112, '2018-04-04 13:55:16'),
(13, 166, '2018-04-04 13:55:16'),
(14, 301, '2018-04-04 13:55:16'),
(15, 302, '2018-04-04 13:55:16'),
(16, 81, '2018-04-04 13:55:16'),
(17, 292, '2018-04-04 13:55:16'),
(18, 291, '2018-04-04 13:55:17'),
(19, 241, '2018-04-04 13:55:17'),
(20, 243, '2018-04-04 13:55:17'),
(21, 242, '2018-04-04 13:55:17'),
(22, 303, '2018-04-04 13:55:17'),
(23, 306, '2018-04-04 13:55:18'),
(24, 10, '2018-04-04 13:55:18'),
(25, 309, '2018-04-04 13:55:18'),
(26, 310, '2018-04-04 13:55:19'),
(27, 147, '2018-04-04 13:55:19'),
(28, 191, '2018-04-04 13:55:19'),
(29, 270, '2018-04-04 13:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `app_dispatch_jobs`
--

CREATE TABLE `app_dispatch_jobs` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `delivery_note` varchar(225) NOT NULL,
  `invoice_no` varchar(225) DEFAULT NULL,
  `unit_price` double(11,2) DEFAULT '0.00',
  `VAT` double(11,2) DEFAULT '0.00',
  `qty` int(11) NOT NULL,
  `start_no` varchar(225) DEFAULT NULL,
  `end_no` varchar(225) DEFAULT NULL,
  `packed_by` varchar(225) NOT NULL,
  `delivered_by` varchar(225) NOT NULL,
  `dispatch_date` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_drafts`
--

CREATE TABLE `app_drafts` (
  `id` int(11) NOT NULL,
  `file_type` varchar(225) NOT NULL,
  `file_name` varchar(225) NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_inks`
--

CREATE TABLE `app_inks` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_inks`
--

INSERT INTO `app_inks` (`id`, `name`) VALUES
(1, 'Black'),
(2, 'Cyan'),
(3, 'Yellow'),
(4, 'Magenta'),
(5, 'Gold'),
(6, 'Gray'),
(7, 'Brown'),
(8, 'Orange'),
(9, 'Blue'),
(10, 'Green'),
(11, 'Red'),
(12, 'Full Color'),
(13, 'Mixed Colors'),
(14, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `app_inks_job_cards`
--

CREATE TABLE `app_inks_job_cards` (
  `id` int(11) NOT NULL,
  `ink_id` int(11) DEFAULT NULL,
  `job_card_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_jobs`
--

CREATE TABLE `app_jobs` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `paper_color_id` int(11) DEFAULT NULL,
  `paper_type_id` int(11) DEFAULT NULL,
  `paper_size_id` int(11) DEFAULT NULL,
  `printed` enum('0','1') NOT NULL DEFAULT '1',
  `numbered` enum('0','1') NOT NULL DEFAULT '0',
  `peforated` enum('0','1') NOT NULL DEFAULT '0',
  `qty` int(225) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_jobs_print_jobs`
--

CREATE TABLE `app_jobs_print_jobs` (
  `id` int(11) NOT NULL,
  `print_job_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_jobs_print_jobs`
--

INSERT INTO `app_jobs_print_jobs` (`id`, `print_job_id`, `job_id`) VALUES
(4, 4, 4),
(5, 5, 4),
(6, 6, 4),
(7, 7, 7),
(8, 8, 7),
(9, 9, 7),
(10, 10, 4),
(11, 11, 4),
(12, 12, 4);

-- --------------------------------------------------------

--
-- Table structure for table `app_job_cards`
--

CREATE TABLE `app_job_cards` (
  `id` int(11) NOT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `current_status` int(11) NOT NULL,
  `order_no` varchar(225) NOT NULL,
  `card_no` varchar(225) NOT NULL,
  `title` varchar(225) NOT NULL,
  `total_qty` int(225) NOT NULL,
  `pages` int(225) NOT NULL,
  `copies` int(11) NOT NULL,
  `user` varchar(225) DEFAULT NULL,
  `comments` text,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_job_cards_operational_period`
--

CREATE TABLE `app_job_cards_operational_period` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `operational_period_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_job_cards_statuses`
--

CREATE TABLE `app_job_cards_statuses` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_job_numbering`
--

CREATE TABLE `app_job_numbering` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `start` varchar(225) NOT NULL,
  `end` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_job_types`
--

CREATE TABLE `app_job_types` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_login_attempts`
--

CREATE TABLE `app_login_attempts` (
  `id` bigint(20) NOT NULL,
  `ip_address` varchar(40) NOT NULL,
  `login` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `app_machines`
--

CREATE TABLE `app_machines` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_machines`
--

INSERT INTO `app_machines` (`id`, `name`) VALUES
(1, 'SM102'),
(2, 'SM 72'),
(3, 'SO KZ'),
(4, 'GTO'),
(5, 'KORD1'),
(6, 'KORD2'),
(7, 'KORD3'),
(8, 'RISO');

-- --------------------------------------------------------

--
-- Table structure for table `app_material_disbursement`
--

CREATE TABLE `app_material_disbursement` (
  `id` int(11) NOT NULL,
  `job_card_id` int(11) DEFAULT NULL,
  `material` varchar(225) NOT NULL,
  `amount` float DEFAULT NULL,
  `measurement_unit_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_material_disbursement`
--

INSERT INTO `app_material_disbursement` (`id`, `job_card_id`, `material`, `amount`, `measurement_unit_id`) VALUES
(1, NULL, 'ink', 2, 1),
(2, NULL, 'ink', 1, 1),
(3, NULL, 'ink', 1, 1),
(4, 2, 'ink', 2, 1),
(5, 2, 'ink', 1, 1),
(6, 3, 'ink', 3, 1),
(7, NULL, 'ink', 2, 1),
(8, NULL, 'ink', 2, 1),
(9, NULL, 'ink', 2, 1),
(10, 2, 'ink', 2, 1),
(11, 2, 'ink', 2, 1),
(12, 2, 'ink', 2, 1),
(13, 2, 'ink', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_measurement_units`
--

CREATE TABLE `app_measurement_units` (
  `id` int(11) NOT NULL,
  `type` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_measurement_units`
--

INSERT INTO `app_measurement_units` (`id`, `type`) VALUES
(1, 'Litre'),
(2, 'Rim');

-- --------------------------------------------------------

--
-- Table structure for table `app_numbering`
--

CREATE TABLE `app_numbering` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `start` int(225) NOT NULL,
  `end` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_operational_period`
--

CREATE TABLE `app_operational_period` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `flag` enum('active','closed') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_operational_period`
--

INSERT INTO `app_operational_period` (`id`, `start_date`, `end_date`, `flag`) VALUES
(1, '2014-01-01', '2014-12-31', 'closed'),
(2, '2014-01-01', '2014-12-31', 'closed'),
(3, '2014-01-01', '2014-12-31', 'closed'),
(4, '2014-01-01', '2014-12-31', 'closed'),
(5, '2015-01-01', '2015-12-31', 'closed'),
(6, '2016-01-01', '2016-12-31', 'closed'),
(7, '2017-01-01', '2017-12-31', 'closed'),
(8, '2018-01-01', '2018-12-31', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `app_packaging`
--

CREATE TABLE `app_packaging` (
  `id` int(11) NOT NULL,
  `job_numbering_id` int(11) DEFAULT NULL,
  `package_qty` int(225) NOT NULL,
  `checked_by` varchar(225) DEFAULT NULL,
  `packed_by` varchar(225) DEFAULT NULL,
  `delivered_by` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_paper_colors`
--

CREATE TABLE `app_paper_colors` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_paper_colors`
--

INSERT INTO `app_paper_colors` (`id`, `name`) VALUES
(1, 'White'),
(2, 'Blue'),
(3, 'Pink'),
(4, 'Yellow'),
(5, 'Green');

-- --------------------------------------------------------

--
-- Table structure for table `app_paper_sizes`
--

CREATE TABLE `app_paper_sizes` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_paper_sizes`
--

INSERT INTO `app_paper_sizes` (`id`, `name`) VALUES
(1, 'A1'),
(2, 'A2'),
(3, 'A3'),
(4, 'A4'),
(5, 'A5'),
(6, 'A6'),
(7, 'BC'),
(8, 'B5'),
(9, 'DL SIZE'),
(10, 'B5'),
(11, 'Business card'),
(12, 'Business card'),
(13, 'B4');

-- --------------------------------------------------------

--
-- Table structure for table `app_paper_types`
--

CREATE TABLE `app_paper_types` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_paper_types`
--

INSERT INTO `app_paper_types` (`id`, `name`, `is_deleted`) VALUES
(1, 'Gloss', '1'),
(2, 'Plain', '1'),
(3, 'Bond', '1'),
(4, 'Bank', '0'),
(5, 'Gloss 135gsm', '0'),
(6, 'Gloss 150gsm', '1'),
(7, 'Gloss 150gsm', '0'),
(8, 'Gloss 90gsm', '0'),
(9, 'Gloss 115gsm', '0'),
(10, 'Gloss 170gsm', '0'),
(11, 'Gloss 200gsm', '0'),
(12, 'Gloss 230gsm', '0'),
(13, 'Gloss 250gsm', '0'),
(14, 'Gloss 300gsm', '0'),
(15, 'Bond 60gsm', '0'),
(16, 'Bond 70gsm', '0'),
(17, 'Bond 80gsm', '0'),
(18, 'Bond 100gsm', '0'),
(19, 'NCR', '0'),
(20, 'Manila 160gsm', '0'),
(21, 'Manila 200gsm', '0'),
(22, 'Manila 240gsm', '0'),
(23, 'News Print', '0'),
(24, 'Self Adhesive Paper', '0'),
(25, 'LEDGER PAPER', '0'),
(26, 'WHITE BOARD 300', '0'),
(27, 'A4', '0'),
(28, 'Matt 135gsm', '0'),
(29, 'Matt 135gsm', '0'),
(30, 'BANNER', '0'),
(31, 'MATT 300', '0'),
(32, 'VINYL', '0'),
(33, 'Matt 170gsm', '0'),
(34, 'Gloss 110gsm', '0'),
(35, 'Gloss 90gsm', '0'),
(36, 'CONQUEROR PAPER', '0'),
(37, 'Matt 90gsm', '0'),
(38, 'MATT 200GSM', '0');

-- --------------------------------------------------------

--
-- Table structure for table `app_permissions`
--

CREATE TABLE `app_permissions` (
  `permission_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(100) NOT NULL,
  `status` enum('active','inactive','deleted') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_permissions`
--

INSERT INTO `app_permissions` (`permission_id`, `name`, `description`, `status`) VALUES
(1, 'Site.Signin.Allow', 'Allow users to login to the site', 'active'),
(2, 'Site.Content.View', 'Allow users to view the Content Context', 'active'),
(3, 'Site.Reports.View', 'Allow users to view the Reports Context', 'active'),
(4, 'Site.Settings.View', 'Allow users to view the Settings Context', 'active'),
(5, 'Site.Developer.View', 'Allow users to view the Developer Context', 'active'),
(6, 'app.Roles.Manage', 'Allow users to manage the user Roles', 'active'),
(7, 'app.Users.Manage', 'Allow users to manage the site Users', 'active'),
(8, 'app.Users.View', 'Allow users access to the User Settings', 'active'),
(9, 'app.Users.Add', 'Allow users to add new Users', 'active'),
(10, 'app.Database.Manage', 'Allow users to manage the Database settings', 'active'),
(11, 'app.Emailer.Manage', 'Allow users to manage the Emailer settings', 'active'),
(12, 'app.Logs.View', 'Allow users access to the Log details', 'active'),
(13, 'app.Logs.Manage', 'Allow users to manage the Log files', 'active'),
(14, 'app.Emailer.View', 'Allow users access to the Emailer settings', 'active'),
(15, 'Site.Signin.Offline', 'Allow users to login to the site when the site is offline', 'active'),
(16, 'app.Permissions.View', 'Allow access to view the Permissions menu unders Settings Context', 'active'),
(17, 'app.Permissions.Manage', 'Allow access to manage the Permissions in the system', 'active'),
(18, 'app.Roles.Delete', 'Allow users to delete user Roles', 'active'),
(19, 'app.Modules.Add', 'Allow creation of modules with the builder.', 'active'),
(20, 'app.Modules.Delete', 'Allow deletion of modules.', 'active'),
(21, 'Permissions.Administrator.Manage', 'To manage the access control permissions for the Administrator role.', 'active'),
(22, 'Permissions.Editor.Manage', 'To manage the access control permissions for the Editor role.', 'active'),
(24, 'Permissions.User.Manage', 'To manage the access control permissions for the User role.', 'active'),
(25, 'Permissions.Developer.Manage', 'To manage the access control permissions for the Developer role.', 'active'),
(27, 'Activities.Own.View', 'To view the users own activity logs', 'active'),
(28, 'Activities.Own.Delete', 'To delete the users own activity logs', 'active'),
(29, 'Activities.User.View', 'To view the user activity logs', 'active'),
(30, 'Activities.User.Delete', 'To delete the user activity logs, except own', 'active'),
(31, 'Activities.Module.View', 'To view the module activity logs', 'active'),
(32, 'Activities.Module.Delete', 'To delete the module activity logs', 'active'),
(33, 'Activities.Date.View', 'To view the users own activity logs', 'active'),
(34, 'Activities.Date.Delete', 'To delete the dated activity logs', 'active'),
(35, 'app.UI.Manage', 'Manage the app UI settings', 'active'),
(36, 'app.Settings.View', 'To view the site settings page.', 'active'),
(37, 'app.Settings.Manage', 'To manage the site settings.', 'active'),
(38, 'app.Activities.View', 'To view the Activities menu.', 'active'),
(39, 'app.Database.View', 'To view the Database menu.', 'active'),
(40, 'app.Migrations.View', 'To view the Migrations menu.', 'active'),
(41, 'app.Builder.View', 'To view the Modulebuilder menu.', 'active'),
(42, 'app.Roles.View', 'To view the Roles menu.', 'active'),
(43, 'app.Sysinfo.View', 'To view the System Information page.', 'active'),
(44, 'app.Translate.Manage', 'To manage the Language Translation.', 'active'),
(45, 'app.Translate.View', 'To view the Language Translate menu.', 'active'),
(46, 'app.UI.View', 'To view the UI/Keyboard Shortcut menu.', 'active'),
(47, 'app.Update.Manage', 'To manage the app Update.', 'active'),
(48, 'app.Update.View', 'To view the Developer Update menu.', 'active'),
(49, 'app.Profiler.View', 'To view the Console Profiler Bar.', 'active'),
(50, 'app.Roles.Add', 'To add New Roles', 'active'),
(79, 'Permissions.General Manager.Manage', 'To manage the access control permissions for the General Manager role.', 'active'),
(80, 'Permissions.Job Card Issuer.Manage', 'To manage the access control permissions for the Job Card Issuer role.', 'active'),
(81, 'Permissions.Pricing Issuer.Manage', 'To manage the access control permissions for the Pricing Issuer role.', 'active'),
(82, 'Permissions.Director.Manage', 'To manage the access control permissions for the Director role.', 'active'),
(83, 'printapp.admin.view', 'view administration section', 'active'),
(84, 'printapp.admin.manage', 'manage administration section', 'active'),
(85, 'printapp.design.view', 'View design section', 'active'),
(86, 'printapp.design.manage', 'manage design section', 'active'),
(87, 'printapp.printpro.view', 'view print production section', 'active'),
(88, 'printapp.dispatch.view', 'view dispatch section', 'active'),
(89, 'printapp.printpro.manage', 'manage print production', 'active'),
(90, 'printapp.dispatch.manage', 'manage dispatch', 'active'),
(91, 'printapp.pricing.manage', 'manage pricing', 'active'),
(92, 'printapp.close.manage', 'manage closed job cards', 'active'),
(93, 'printapp.quotation.manage', 'manage quotation manager', 'active'),
(94, 'Permissions.Production Manager.Manage', 'To manage the access control permissions for the Production Manager role.', 'active'),
(95, 'Permissions.Designer.Manage', 'To manage the access control permissions for the Designer role.', 'active'),
(96, 'printapp.quotation.view', 'View quotations', 'active'),
(97, 'printapp.close.view', 'View Closed job cards', 'active'),
(98, 'printapp.pricing.view', 'View job card pricing', 'active'),
(99, 'printapp.dispatch.edit', 'Edit Dispatch Details', 'active'),
(100, 'printapp.jobcard.delete', 'Delete jobcard', 'active'),
(101, 'printapp.jobcard.edit', 'Ability to edit job card', 'active'),
(102, 'printapp.admin.delete', 'Delete Job cards', 'active'),
(103, 'printapp.admin.edit', 'Edit Job Cards', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `app_print_jobs`
--

CREATE TABLE `app_print_jobs` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `printed_by` varchar(225) NOT NULL,
  `qty_printed` int(11) NOT NULL,
  `machine_id` int(11) DEFAULT NULL,
  `date_printed` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_quotations`
--

CREATE TABLE `app_quotations` (
  `id` int(11) NOT NULL,
  `quotation_number` int(11) NOT NULL,
  `customer_name` varchar(225) DEFAULT NULL,
  `attention` varchar(225) DEFAULT NULL,
  `address` text NOT NULL,
  `details` text NOT NULL,
  `transaction_key` varchar(225) NOT NULL,
  `is_closed` enum('0','1') NOT NULL DEFAULT '0',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_roles`
--

CREATE TABLE `app_roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '1',
  `login_destination` varchar(255) NOT NULL DEFAULT '/',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `default_context` varchar(255) NOT NULL DEFAULT 'content'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_roles`
--

INSERT INTO `app_roles` (`role_id`, `role_name`, `description`, `default`, `can_delete`, `login_destination`, `deleted`, `default_context`) VALUES
(1, 'Administrator', 'Has full control over every aspect of the site.', 0, 0, '/administration', 0, 'content'),
(2, 'Editor', 'Can handle day-to-day management, but does not have full power.', 0, 1, '', 0, 'content'),
(4, 'User', 'This is the default user with access to login.', 1, 0, '/administration', 0, 'content'),
(6, 'Developer', 'Developers typically are the only ones that can access the developer tools. Otherwise identical to Administrators, at least until the site is handed off.', 0, 1, '/administration', 0, 'content'),
(7, 'Warehouse Inspector', 'Has Read Only rights to the warehouse', 0, 1, '', 1, 'content'),
(8, 'Warehouse Clerk', 'Data Entry Clerk from the warehouse', 0, 1, '/', 1, 'content'),
(9, 'Manager', 'Can views reports but has no rights to enter data.', 0, 1, '/', 1, 'content'),
(10, 'Designer', 'Uploads draft Art work', 0, 0, '/design/pending', 1, 'content'),
(11, 'Production Manager', 'Manages general areas relating to production ', 0, 1, 'public/print', 1, 'content'),
(12, 'Front Office', 'Front office person', 0, 1, '/administration', 1, 'content'),
(13, 'General Manager', 'General management rights', 0, 0, 'public/administration', 0, 'content'),
(14, 'Job Card Issuer', 'Issues Job cards', 0, 0, '/administration', 0, 'content'),
(15, 'Pricing Issuer', 'Does the job card pricing', 0, 0, '/pricing', 0, 'content'),
(16, 'Director', 'Has full access to application', 0, 0, 'public/administration', 0, 'content'),
(17, 'Production Manager', 'Manages general areas relating to production', 0, 1, '/print', 0, 'content'),
(18, 'Designer', 'Uploads draft Art work', 0, 1, '/design/pending', 0, 'content');

-- --------------------------------------------------------

--
-- Table structure for table `app_role_permissions`
--

CREATE TABLE `app_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_role_permissions`
--

INSERT INTO `app_role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 24),
(1, 25),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(1, 39),
(1, 40),
(1, 41),
(1, 42),
(1, 43),
(1, 44),
(1, 45),
(1, 46),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 79),
(1, 80),
(1, 81),
(1, 82),
(1, 83),
(1, 84),
(1, 85),
(1, 86),
(1, 87),
(1, 88),
(1, 89),
(1, 90),
(1, 91),
(1, 92),
(1, 93),
(1, 94),
(1, 95),
(1, 96),
(1, 97),
(1, 98),
(1, 99),
(1, 100),
(1, 101),
(1, 102),
(1, 103),
(2, 1),
(2, 2),
(2, 3),
(4, 1),
(4, 24),
(4, 27),
(4, 29),
(6, 1),
(6, 2),
(6, 3),
(6, 4),
(6, 5),
(6, 6),
(6, 7),
(6, 8),
(6, 9),
(6, 10),
(6, 11),
(6, 12),
(6, 13),
(6, 49),
(11, 1),
(11, 2),
(11, 3),
(11, 12),
(13, 1),
(13, 2),
(13, 83),
(13, 84),
(13, 85),
(13, 86),
(13, 87),
(13, 88),
(13, 89),
(13, 90),
(14, 1),
(14, 2),
(14, 15),
(14, 83),
(14, 84),
(14, 85),
(14, 86),
(14, 87),
(14, 88),
(14, 89),
(14, 93),
(14, 96),
(14, 97),
(14, 98),
(15, 1),
(15, 2),
(15, 3),
(15, 85),
(15, 87),
(15, 88),
(15, 91),
(15, 96),
(15, 97),
(15, 98),
(16, 1),
(16, 2),
(16, 3),
(16, 15),
(16, 83),
(16, 84),
(16, 85),
(16, 86),
(16, 87),
(16, 88),
(16, 89),
(16, 90),
(16, 91),
(16, 92),
(16, 93),
(17, 1),
(17, 2),
(17, 83),
(17, 85),
(17, 87),
(17, 88),
(17, 89),
(17, 90),
(17, 97),
(18, 1),
(18, 2),
(18, 85),
(18, 86);

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE `app_settings` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `name`, `module`, `value`) VALUES
(1, 'auth.allow_name_change', 'core', '1'),
(2, 'auth.allow_register', 'core', '0'),
(3, 'auth.allow_remember', 'core', '1'),
(4, 'auth.do_login_redirect', 'core', '1'),
(5, 'auth.login_type', 'core', 'username'),
(6, 'auth.name_change_frequency', 'core', '1'),
(7, 'auth.name_change_limit', 'core', '1'),
(8, 'auth.password_force_mixed_case', 'core', '0'),
(9, 'auth.password_force_numbers', 'core', '0'),
(10, 'auth.password_force_symbols', 'core', '0'),
(11, 'auth.password_min_length', 'core', '8'),
(12, 'auth.password_show_labels', 'core', '0'),
(13, 'auth.remember_length', 'core', '2592000'),
(14, 'auth.use_extended_profile', 'core', '0'),
(15, 'auth.use_usernames', 'core', '1'),
(16, 'auth.user_activation_method', 'core', '0'),
(17, 'site.languages', 'core', 'a:1:{i:0;s:7:\"english\";}'),
(18, 'site.list_limit', 'core', '10'),
(19, 'site.show_front_profiler', 'core', '0'),
(20, 'site.show_profiler', 'core', '0'),
(21, 'site.status', 'core', '1'),
(22, 'site.system_email', 'core', 'app@site.com'),
(23, 'site.title', 'core', 'Warehouse Management System {Room to Read Zambia}');

-- --------------------------------------------------------

--
-- Table structure for table `app_statuses`
--

CREATE TABLE `app_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_statuses`
--

INSERT INTO `app_statuses` (`id`, `name`) VALUES
(1, 'Issued Job Card'),
(2, 'Awaiting Sample'),
(3, 'Designing'),
(4, 'Designing Complete'),
(5, 'Awaiting Approval'),
(6, 'Printing'),
(7, 'Printing Complete'),
(8, 'Binding'),
(9, 'Binding Complete'),
(10, 'Dispatch'),
(11, 'Dispatch Complete'),
(12, 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE `app_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '4',
  `email` varchar(120) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password_hash` varchar(40) NOT NULL,
  `reset_hash` varchar(40) DEFAULT NULL,
  `salt` varchar(7) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(40) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_message` varchar(255) DEFAULT NULL,
  `reset_by` int(10) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT '',
  `display_name_changed` date DEFAULT NULL,
  `timezone` char(4) NOT NULL DEFAULT 'UM6',
  `language` varchar(20) NOT NULL DEFAULT 'english',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activate_hash` varchar(40) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`id`, `role_id`, `email`, `username`, `password_hash`, `reset_hash`, `salt`, `last_login`, `last_ip`, `created_on`, `deleted`, `banned`, `ban_message`, `reset_by`, `display_name`, `display_name_changed`, `timezone`, `language`, `active`, `activate_hash`) VALUES
(1, 1, 'proprint@zamnet.zm', 'super.user', 'f936adcd770b3ee55e6805d24c8547d31516b41a', NULL, 'W5jSFg5', '2018-10-26 10:12:48', '192.168.0.56', '0000-00-00 00:00:00', 0, 0, NULL, NULL, 'Administrator', NULL, 'UP2', 'english', 1, ''),
(3, 1, 'Daliablu8907@gmail.com', 'daliso.lungu', 'e6f8498836d5ee4fc6dcb8f7478ea7d668d9a33c', NULL, 'DznUixV', '2018-11-06 14:20:16', '::1', '2015-01-25 10:42:18', 0, 0, NULL, NULL, 'Daliso Lungu', NULL, 'UP2', 'english', 1, ''),
(5, 17, 'production@proprintzambia.com', 'Alpesh', '48f8fdb02a2e4329fcd5f2c2450c5b21a94eb27c', NULL, '58iIYF7', '2018-10-26 17:00:59', '192.168.0.35', '2015-01-26 11:04:22', 0, 0, NULL, NULL, 'Production Manager', NULL, 'UP2', 'english', 1, ''),
(6, 1, 'proprintart@gmail.com', 'Hiral', '53882e97a1b121abd98f9576a5de515730944471', NULL, 'dbsaEgc', '2018-10-26 09:20:41', '192.168.0.134', '2015-01-29 16:45:59', 0, 0, NULL, NULL, 'Hiral Patel', NULL, 'UP2', 'english', 1, ''),
(7, 15, 'sales@proprintzambia.com', 'PATRICIA', 'acafebdbc61b39746a04f4aba8773aa5e1d31af5', NULL, 'p1bwn1N', '0000-00-00 00:00:00', '', '2016-01-19 18:05:40', 0, 0, NULL, NULL, 'PATRICIA', NULL, 'UP2', 'english', 1, ''),
(8, 18, 'info@proprintzambia.com', 'sakala', '5b43d52eef6927bf9c0c4b20a1a5da55fee9b871', NULL, 'V2qE3PE', '2018-10-26 12:28:23', '192.168.0.16', '2018-10-05 13:02:07', 0, 0, NULL, NULL, 'Sakala', NULL, 'UP2', 'english', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `app_user_cookies`
--

CREATE TABLE `app_user_cookies` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(128) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_user_cookies`
--

INSERT INTO `app_user_cookies` (`user_id`, `token`, `created_on`) VALUES
(1, 'r4EDysbuDErYnxfuP6ox3TRwiBJZOBaD0v7JyPghqUYMjbotXG18xEmwClktl07dFhUG2gWvtfaQ3pSk1s5KmpHvCXSJ9gIZMzRnfycAw1iOkZmN0U5WAAT8jz9L4Mli', '2014-12-23 18:33:44'),
(1, 'YPbPRoKRthLljSVjdC0iQhgJzQA54k9MXoF07YMWNSnkUOeRMi8rDG7s6xFtw4q3XDGL7FhHpm2o9KAk6VlI8au2JJ6n5Z8xYTNyqCEaCKOnWUxByIlQjEvduicAHcf9', '2014-12-24 01:58:51'),
(1, 'FUEvKmHC12GiSrZbRsEJWvfRRFDql8dZX9tnjPsuU4fNNwJ3jFVMJPB7pziKcSauIEGtz8y0oIeousgvkYQNqiLc9rBTxyxK3A4m5OYwljSfmTVLIDaB2O0QgbhAZp9V', '2014-12-24 19:38:32'),
(1, 'RzN6ZshZOiqSj4gxA2BxzF0048K751btVVFq4cZS7CwvOGMt5YKECT6Uuimp8hRkVEsRHXXl9ojzyrr1f7WpL3fQTnFf9e6GBEotqyrba2ONdbjYcyMdDJNUQ0GgHQmP', '2014-12-26 07:51:58'),
(1, 'U7XNcJuK9cjfxwXPJrknGT0RMy9TidgNSHyYQ3hizv1bhssZH8DMZExKLnYNM4tarWJpWIgRTC3dhVtLcAkimpC5bqRAUOQqCEO0loDXSunpook5APKbmBe2V6Sa6F1w', '2014-12-28 08:02:51'),
(1, 'ay6EZ80zLoWFCIsLMchXuhlbrreAO196R27nxay3pwRYjSijES1eWVtedEC8QYwUvVvHSY5sT5BsqD7BNxVIIqguPW4OmGd4z3KvU47nhjLloZbbUNmMNtotD9iuFKkx', '2014-12-30 02:59:27'),
(1, 'Kkqur1UCGQ3GCapdZzk2vg7Od7QTMkSPLFU0I4bc0DrAIs8YN6wu3hNDTSZg9TVOyRfzhHaURqHomnXob4FKPxLGBn8eAscjtrLJ53tRY8voOwnjNBWFVK7ellmp1iX0', '2014-12-30 07:38:47'),
(1, 'GY6V9EzLD3m0VHWcQNSKkUlNmGzGv43FEjVyo9dEp9C88FHlTYmJKMeRCXzpKv5Nri2DR6KFDdqHX6GIUia8XqKrvuuzqRousuZnLyYwC6NbxrjFmzBKZjjnMNfIRejE', '2015-01-07 06:41:39'),
(1, 'tomQJmndUgUuCaDtiNBn0qwJlEREEGdTlFvbZKqyM40rfHAYTTrxRsJ2IWxO94y6IbFagSe5jwLoOqzcKgprVScMBWBFOh317HZVI0Aii21zeW78LD8hZk3UxQbluXYd', '2014-12-31 07:39:20'),
(1, 'jwPX3Fk6F97tCx9ZzUV4abyE8Pjdc7FVXueVIa1Dkt5cZ7oClfqQsFdAmyT3I9g2VeltAivZyc9NDVy9EPZ1sINJ7PxLRWyhba5lxi8FXrFVsgRZYnsApPkUy62VhmUu', '2014-12-31 12:30:39'),
(1, 'zDrtqt1YLYA4i91OBib4EyatcpJBanfz3xGuQHkZEBwiG12yJNFdt72mvBlGEMxoc3YG3l0WvNlCAvX9PM1xHHuBDci4aWwbxqOfuRuoaWf1Z0zkNm4Cy821lZX5b2oO', '2015-01-02 16:29:03'),
(1, 'a8pZMM5NpHmHTUJQDjrenRjm86DzK8R9YN9b4bvEZvmG2NH9v5zFfmFuy7PHgpvajgQF6MqwpvnEIxL6i3rA8DVzhyczieK9Bf0whPBMqYvkVh5TNDjX17vzIC2XCsWE', '2015-01-05 02:32:31'),
(1, 'X48vBCiZZVYflTjZfcplrOJXc3oDglB0zo6J7nj6iTdw8xjdnoGmsLE9dTJWxljaXoL9BU9K2jGKRkD6QPbBJYbKXSOPy9YKkRWRO9bKPzYW6Vifax8qQh6G9NmDxgR9', '2015-01-19 13:50:13'),
(1, 'GvSpUzhjtSixBtxplf0W74EXqKUJG60JWnNBSusOG1yb64LGFExJvgoBuZlkwbcg9EosCuSw9aJmbAOv0yUAI329WnLHeJv5aLUasdekiENKgwcyGKKX4l3B47kW2Q0q', '2015-01-20 06:47:14'),
(1, 'zK8To4ytKQf6LZkHMKTGtIloe7mI047tiHTBU8eCqUKtD3uzu3c6tZ6Vqrva7nYixLEPmy7WvR5JyLZsFkjQcibukRVCfMVEsfq3U1WrZ9ZeSeoeRYTAzfVgHWoi8xf6', '2015-01-25 07:45:09'),
(6, '1DwVmUtsFWNSy2cHgFfdCcfYOlMg10C6wmftq6Qk1ZYNSSes7sUdS0UM53AiF3iPfW8k865c07BsNVSdWcViGiWsSQa5sTX668ghsQ1ttszQOYcQYScU1SyldGVbnP2o', '2016-09-22 08:51:21'),
(3, 'bQbTYm6bISnza7HpnYjsI7HmT0bg4eXkxwCwjg5PHV4JF7r8UUqvRFr87unT6z6myDMFwojmigFvw2g0CO0B58X1wSO5wzLpza6my1F2FAYwTX0OVl8mO9WzglTqRsrt', '2017-01-09 10:02:06'),
(6, '5FX0bbgwcXZPnjN3YyrIT3zFbTOtXHHNZA9MMG6Bz6ePWG8aNXe34l2DV6AIrLqCVKmvL7ZsdAhHNHH7h3A0ifrc4Z2LfUMe5YlEW1JWj8kZZ5FOf85qOr93IPXvbqph', '2016-11-08 17:13:27'),
(3, 'JktJCjJeuyLrJNpKmJY67zmdkDKU33K2yACQ6RryfY1YtGhcyqHxqeiFYex4gBtxrnczhdtfeh91joN6pSl1UbQEbydiimm9hxIJYZmhU7mwEf4az2Mzo81JBRR7gVUn', '2017-01-09 10:07:00'),
(6, 'JibxzgILm2sg51L4QuSP1HkoCanOhZ7XpbMze8F4EgFRSKzD9KKNIgbw1KAzjVa7HHgtkCRUt3QN8omnFYf5luqmyApndyl4pkaeQhTM37fRU87FM5SczkHDInnVlU1R', '2017-08-05 11:26:53'),
(1, 'nsrKpsuEpsW392U4RgQsfg8Rraw6D8Ei8WXqi73bILSyQoLw94czcQCt3j2H1I6nlLrZdeqcvqtq3NmVgx7dIeAoM4cZT569h2RAjZSMIkiYCBOoOLwOfhRKSmezlz0N', '2018-01-12 14:37:11'),
(1, 'wQ9fAKAaqRLphCz7OGliRloZxm8PL0bOjmXqi0I1QYwBOSbZ5kYkWyboanSDxMQjbNZniTaLj0ZxrnaAfv3Xb3I5XQmlKpMDVpttKQJOHL0pGQXraJFjbG6e5WgTHMRs', '2018-02-21 13:15:05'),
(1, 'htP5pZTF3RtwS1ssVcOGAoi0buXxGOZP0vtVD17hdwX4L9kqjcHiBwJBH0wqMHjJmYbGh9zdo8lGiiuGUCwsPDqkRzet8QX7ARfDNTqvafHXjUqMZo22lqhBmhoymM4Q', '2018-05-28 14:17:21'),
(1, '3h7GQx4mQtQJneU93TC9M72kPSDG0ey9OShjY3DSkPEw8vnDJgerwnKylE8H2tmSKu5RtnAdiPkQ0JL4eaa8MaarHKq8dlcaLihQzaTgcoIPni5E3icNzcVwgHf3bQYK', '2018-08-08 17:50:58');

-- --------------------------------------------------------

--
-- Table structure for table `app_user_meta`
--

CREATE TABLE `app_user_meta` (
  `meta_id` int(20) UNSIGNED NOT NULL,
  `user_id` int(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) NOT NULL DEFAULT '',
  `meta_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_activities`
--
ALTER TABLE `app_activities`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `app_approved_designs`
--
ALTER TABLE `app_approved_designs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_binding_jobs`
--
ALTER TABLE `app_binding_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_binding_jobs_dispatch_jobs`
--
ALTER TABLE `app_binding_jobs_dispatch_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_binding_types`
--
ALTER TABLE `app_binding_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_company`
--
ALTER TABLE `app_company`
  ADD PRIMARY KEY (`pk_i_id`);

--
-- Indexes for table `app_complete_job_cards`
--
ALTER TABLE `app_complete_job_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_customers`
--
ALTER TABLE `app_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_customers_job_cards`
--
ALTER TABLE `app_customers_job_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_designs`
--
ALTER TABLE `app_designs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_designs_drafts`
--
ALTER TABLE `app_designs_drafts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_dispatche`
--
ALTER TABLE `app_dispatche`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_dispatches`
--
ALTER TABLE `app_dispatches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_dispatch_jobs`
--
ALTER TABLE `app_dispatch_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_drafts`
--
ALTER TABLE `app_drafts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_inks`
--
ALTER TABLE `app_inks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_inks_job_cards`
--
ALTER TABLE `app_inks_job_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_jobs`
--
ALTER TABLE `app_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_jobs_print_jobs`
--
ALTER TABLE `app_jobs_print_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_job_cards`
--
ALTER TABLE `app_job_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_job_cards_operational_period`
--
ALTER TABLE `app_job_cards_operational_period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_job_cards_statuses`
--
ALTER TABLE `app_job_cards_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_job_numbering`
--
ALTER TABLE `app_job_numbering`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_job_types`
--
ALTER TABLE `app_job_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_login_attempts`
--
ALTER TABLE `app_login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_machines`
--
ALTER TABLE `app_machines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_material_disbursement`
--
ALTER TABLE `app_material_disbursement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_measurement_units`
--
ALTER TABLE `app_measurement_units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_numbering`
--
ALTER TABLE `app_numbering`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_operational_period`
--
ALTER TABLE `app_operational_period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_packaging`
--
ALTER TABLE `app_packaging`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_paper_colors`
--
ALTER TABLE `app_paper_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_paper_sizes`
--
ALTER TABLE `app_paper_sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_paper_types`
--
ALTER TABLE `app_paper_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_permissions`
--
ALTER TABLE `app_permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `app_print_jobs`
--
ALTER TABLE `app_print_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_quotations`
--
ALTER TABLE `app_quotations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_roles`
--
ALTER TABLE `app_roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `app_role_permissions`
--
ALTER TABLE `app_role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`);

--
-- Indexes for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique - name` (`name`),
  ADD KEY `index - name` (`name`);

--
-- Indexes for table `app_statuses`
--
ALTER TABLE `app_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_users`
--
ALTER TABLE `app_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `app_user_cookies`
--
ALTER TABLE `app_user_cookies`
  ADD KEY `token` (`token`);

--
-- Indexes for table `app_user_meta`
--
ALTER TABLE `app_user_meta`
  ADD PRIMARY KEY (`meta_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_activities`
--
ALTER TABLE `app_activities`
  MODIFY `activity_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_approved_designs`
--
ALTER TABLE `app_approved_designs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_binding_jobs`
--
ALTER TABLE `app_binding_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_binding_jobs_dispatch_jobs`
--
ALTER TABLE `app_binding_jobs_dispatch_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_binding_types`
--
ALTER TABLE `app_binding_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `app_company`
--
ALTER TABLE `app_company`
  MODIFY `pk_i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `app_complete_job_cards`
--
ALTER TABLE `app_complete_job_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_customers`
--
ALTER TABLE `app_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_customers_job_cards`
--
ALTER TABLE `app_customers_job_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_designs`
--
ALTER TABLE `app_designs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_designs_drafts`
--
ALTER TABLE `app_designs_drafts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_dispatche`
--
ALTER TABLE `app_dispatche`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_dispatches`
--
ALTER TABLE `app_dispatches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `app_dispatch_jobs`
--
ALTER TABLE `app_dispatch_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_drafts`
--
ALTER TABLE `app_drafts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_inks`
--
ALTER TABLE `app_inks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `app_inks_job_cards`
--
ALTER TABLE `app_inks_job_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_jobs`
--
ALTER TABLE `app_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_jobs_print_jobs`
--
ALTER TABLE `app_jobs_print_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `app_job_cards`
--
ALTER TABLE `app_job_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_job_cards_operational_period`
--
ALTER TABLE `app_job_cards_operational_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_job_cards_statuses`
--
ALTER TABLE `app_job_cards_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_job_numbering`
--
ALTER TABLE `app_job_numbering`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_job_types`
--
ALTER TABLE `app_job_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_login_attempts`
--
ALTER TABLE `app_login_attempts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_machines`
--
ALTER TABLE `app_machines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `app_material_disbursement`
--
ALTER TABLE `app_material_disbursement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `app_measurement_units`
--
ALTER TABLE `app_measurement_units`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `app_numbering`
--
ALTER TABLE `app_numbering`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_operational_period`
--
ALTER TABLE `app_operational_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `app_packaging`
--
ALTER TABLE `app_packaging`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_paper_colors`
--
ALTER TABLE `app_paper_colors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `app_paper_sizes`
--
ALTER TABLE `app_paper_sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `app_paper_types`
--
ALTER TABLE `app_paper_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `app_permissions`
--
ALTER TABLE `app_permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;
--
-- AUTO_INCREMENT for table `app_print_jobs`
--
ALTER TABLE `app_print_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_quotations`
--
ALTER TABLE `app_quotations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_roles`
--
ALTER TABLE `app_roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `app_settings`
--
ALTER TABLE `app_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `app_statuses`
--
ALTER TABLE `app_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `app_users`
--
ALTER TABLE `app_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `app_user_meta`
--
ALTER TABLE `app_user_meta`
  MODIFY `meta_id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
